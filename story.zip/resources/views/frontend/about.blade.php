@extends('layouts.app')

@section('content')
    <div class="container">
        <p>سلام - وب سایت بوستان و گلستان کار خودشو از ۱ سال پیش ب منظور انجام پروژه کارشناسی شروع کرده ;)</p>
    </div>
@endsection
