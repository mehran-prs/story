<div class="form-group<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
    <?php echo Form::label('title', 'عنوان', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-8">
        <?php echo Form::text('title', null, ['class' => 'form-control', 'required', 'autofocus']); ?>


        <span class="help-block">
            <strong><?php echo e($errors->first('title')); ?></strong>
        </span>
    </div>
</div>

<div class="form-group<?php echo e($errors->has('poster') ? ' has-error' : ''); ?>">
    <?php echo Form::label('poster', 'پوستر', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-8">
        <?php echo Form::file('poster', null, ['class' => 'form-control', 'required', 'autofocus']); ?>


        <span class="help-block">
            <strong><?php echo e($errors->first('poster')); ?></strong>
        </span>
    </div>
</div>


<div class="form-group<?php echo e($errors->has('poster') ? ' has-error' : ''); ?>">
    <?php echo Form::label('voice', 'قصه شنیدنی', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-8">
        <?php echo Form::file('voice', null, ['class' => 'form-control', 'required', 'autofocus']); ?>


        <span class="help-block">
            <strong><?php echo e($errors->first('voice')); ?></strong>
        </span>
    </div>
</div>

<div class="form-group<?php echo e($errors->has('body') ? ' has-error' : ''); ?>">
    <?php echo Form::label('body', 'قصه', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-8">
        <?php echo Form::textarea('body', null, ['class' => 'form-control', 'required']); ?>


        <span class="help-block">
            <strong><?php echo e($errors->first('body')); ?></strong>
        </span>
    </div>
</div>


<div class="form-group<?php echo e($errors->has('category_id') ? ' has-error' : ''); ?>">
    <?php echo Form::label('category_id', 'دسته', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-8">
        <?php echo Form::select('category_id', $categories, null, ['class' => 'form-control', 'required']); ?>


        <span class="help-block">
            <strong><?php echo e($errors->first('category_id')); ?></strong>
        </span>
    </div>
</div>

<?php 
    if(isset($post)) {
        $tag = $post->tags->pluck('name')->all();
    } else {
        $tag = null;
    }
 ?>
<div class="form-group<?php echo e($errors->has('tags') ? ' has-error' : ''); ?>">
    <?php echo Form::label('tags', 'تگ ها', ['class' => 'col-md-2 control-label']); ?>


    <div class="col-md-8">
        <?php echo Form::select('tags[]', $tags, $tag, ['class' => 'form-control select2-tags', 'required', 'multiple']); ?>


        <span class="help-block">
            <strong><?php echo e($errors->first('tags')); ?></strong>
        </span>
    </div>
</div>
