<div class="row form-search story-search">
    <?php echo Form::open(['method' => 'GET', 'role' => 'form']); ?>

            <div class="col-md-10">
                <?php echo Form::text('search', request()->get('search'), ['class' => 'form-control', 'placeholder' => 'جستجو...']); ?>

            </div>
            <div class="col-md-2">
                <?php echo Form::submit('بگرد', ['class' => 'btn btn-block btn-default']); ?>

            </div>
    <?php echo Form::close(); ?>

</div>
