<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h2>
                            قصه ها

                            <a href="<?php echo e(url('admin/posts/create')); ?>" class="btn btn-default pull-left">داستان جدید</a>
                        </h2>
                    </div>

                    <div class="panel-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>عنوان</th>
                                    <th>قصه</th>
                                    <th>نویسنده</th>
                                    <th>دسته</th>
                                    <th>تگ ها</th>
                                    <th>انتشار</th>
                                    <th>عمل</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($post->title); ?></td>
                                        <td><?php echo e(str_limit($post->body, 60)); ?></td>
                                        <td><?php echo e($post->user->name); ?></td>
                                        <td><?php echo e($post->category->name); ?></td>
                                        <td><?php echo e($post->tags->implode('name', ', ')); ?></td>
                                        <td><?php echo e($post->published); ?></td>
                                        <td>
                                            <?php if(Auth::user()->is_admin): ?>
                                                <?php 
                                                    if($post->published == 'Yes') {
                                                        $label = 'Draft';
                                                    } else {
                                                        $label = 'Publish';
                                                    }
                                                 ?>
                                                <a href="<?php echo e(url("/admin/posts/{$post->id}/publish")); ?>" data-method="PUT" data-token="<?php echo e(csrf_token()); ?>" data-confirm="Are you sure?" class="btn btn-xs btn-warning"><?php echo e($label); ?></a>
                                            <?php endif; ?>
                                            <a href="<?php echo e(url("/admin/posts/{$post->id}")); ?>" class="btn btn-xs btn-success">نمایش</a>
                                            <a href="<?php echo e(url("/admin/posts/{$post->id}/edit")); ?>" class="btn btn-xs btn-info">ویرایش</a>
                                            <a href="<?php echo e(url("/admin/posts/{$post->id}")); ?>" data-method="DELETE" data-token="<?php echo e(csrf_token()); ?>" data-confirm="Are you sure?" class="btn btn-xs btn-danger">حذف</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5">داستانی وجود ندارد</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <?php echo $posts->links(); ?>


                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>