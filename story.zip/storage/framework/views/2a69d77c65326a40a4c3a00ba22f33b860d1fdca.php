<ul class="nav navbar-nav">
    <li><a href="<?php echo e(url('admin/posts')); ?>">قصه ها</a></li>
    <li><a href="<?php echo e(url('admin/categories')); ?>">دسته ها</a></li>
    <li><a href="<?php echo e(url('admin/comments')); ?>">نظرات</a></li>
    <li><a href="<?php echo e(url('admin/tags')); ?>">تگ ها</a></li>

    <?php if(Auth::user()->is_admin): ?>
        <li><a href="<?php echo e(url('admin/users')); ?>">کاربران</a></li>
    <?php endif; ?>
</ul>
