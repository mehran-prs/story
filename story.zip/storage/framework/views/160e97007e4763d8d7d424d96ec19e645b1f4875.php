<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-heading">قصه ها</div>

                    <div class="panel-body">
                        <h1><?php echo e($posts); ?></h1>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-heading">نظرات</div>

                    <div class="panel-body">
                        <h1><?php echo e($comments); ?></h1>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-heading">تگ ها</div>

                    <div class="panel-body">
                        <h1><?php echo e($tags); ?></h1>
                    </div>
                </div>
            </div>

            <div class="col-md-3">
                <div class="panel panel-default">
                    <div class="panel-heading">دسته بندی ها</div>

                    <div class="panel-body">
                        <h1><?php echo e($categories); ?></h1>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>