<?php $__env->startSection('content'); ?>
    <div class="container">

        <?php echo $__env->make('frontend._search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="row">

            <?php $i = 0;?>
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $i++;?>
                <div class="col-md-6">
                    <div class="panel story-card panel-default">
                        <div class="panel-img">
                            <img src="<?php echo e(isset($post->poster) ? Storage::url($post->poster): asset('img/story.jpg')); ?>"
                                 alt="Story Poster">
                        </div>
                        <div class="panel-heading">
                            <?php echo e($post->title); ?> -
                            <small>توسط <?php echo e($post->user->name); ?></small>

                            <span class="text-left block t">
                                <?php echo e($post->created_at->toDayDateTimeString()); ?>

                            </span>
                        </div>

                        <?php if($post->voice): ?>
                            <div class="voice">
                                <audio controls>
                                    <source src="<?php echo e(Storage::url($post->voice)); ?>" type="audio/mpeg">
                                    Your browser does not support the audio element.
                                </audio>
                            </div>
                        <?php endif; ?>

                        <div class="panel-body">
                            <p><?php echo e(str_limit($post->body, 200)); ?></p>
                            <p>
                                تگ ها:
                                <?php $__empty_2 = true; $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                    <span class="label label-default"><?php echo e($tag->name); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <span class="label label-danger">بدون تگ.</span>
                                <?php endif; ?>
                            </p>
                            <p>
                                <span class="btn btn-sm btn-success"><?php echo e($post->category->name); ?></span>
                                <span class="btn btn-sm btn-info">نظرات <span
                                            class="badge"><?php echo e($post->comments_count); ?></span></span>

                                <a href="<?php echo e(url("/posts/{$post->id}")); ?>" class="btn btn-sm btn-primary">خوندن قصه</a>
                            </p>
                        </div>
                    </div>
                </div>

                <?php if($i%2==0): ?>
                    <div class="col-xs-12"></div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="panel panel-default">
                    <div class="panel-heading">یافت نشد!!</div>

                    <div class="panel-body">
                        <p>متاسفانه قصه یافت نشد.</p>
                    </div>
                </div>
            <?php endif; ?>


        </div>
        <div align="center">
            <?php echo $posts->appends(['search' => request()->get('search')])->links(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>